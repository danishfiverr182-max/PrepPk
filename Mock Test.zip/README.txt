PrepPk — Key Pool Verification & Visibility (Prompt 10-11)
=============================================================

Drop each file into your real project at the SAME relative path shown
below (this zip's folder structure already matches your repo layout).

UPDATED (overwrite the existing file):
  server/routes/adminChatAnalytics.js
  server/package.json
  server/services/providers/openaiProvider.js
    Fix: sends max_completion_tokens instead of the deprecated
    max_tokens, so OpenAI reasoning models (o1/o3/o4-mini/gpt-5, etc.)
    no longer 400 with "Unsupported parameter: 'max_tokens'". Scoped to
    OpenAI only   Groq's and OpenRouter's adapters are untouched since
    those OpenAI-compatible APIs still expect max_tokens.
  client/src/pages/admin/ChatAnalyticsPage.jsx
  client/src/pages/admin/ApiKeyPoolPage.jsx

NEW (add these files):
  server/tests/aiKeyPool.spec.js
  server/scripts/testAllKeys.js

NOT included — no changes needed:
  server/controllers/chatController.js
    Verified only. success/providerUsed already default to false/null,
    and the finally block always calls logChatUsage(), so an
    ALL_KEYS_EXHAUSTED failure already writes a ChatLog row with
    success: false, provider: null. Nothing to change here.

How to run the new test file:
  cd server
  npm run test:unit
  (or: node --test tests/aiKeyPool.spec.js)
  → all 5 tests pass using in-memory mocks, no real DB/network needed.

How to run the new CLI script:
  cd server
  npm run test:keys
  (or: node scripts/testAllKeys.js)
  → requires MONGO_URI and ENCRYPTION_KEY in server/.env, and will make
    real trivial test calls to whichever providers are in your vault.
