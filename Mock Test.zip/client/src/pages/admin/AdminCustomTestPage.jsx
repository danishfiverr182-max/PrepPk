/**
 * pages/admin/AdminCustomTestPage.jsx
 *
 * Routes:
 *   /admin/custom-test/:testId          ← canonical (Prompt 9C)
 *   /admin/custom-test/:testId/add-mcqs ← legacy alias (kept for backward compat)
 *
 * Phases driven entirely by test.status from the server:
 *
 *   "settings_pending"  → Phase 1  Time Limit + Total MCQs  → Save Settings
 *                         PATCH /api/custom-tests/:testId/settings
 *                         On success: status becomes "mcqs_pending" → auto-advance
 *
 *   "mcqs_pending" |    → Phase 2  Progress bar + MCQ editor
 *   "in_progress"          MCQs now live in their own collection (Stage 1/2 of
 *                          the MCQ storage refactor). This page (Stage 3):
 *                            POST   /api/custom-tests/:testId/mcqs/batch      (autosave NEW mcqs only)
 *                            PATCH  /api/custom-tests/:testId/mcqs/:mcqId     (edit one already-saved mcq)
 *                            DELETE /api/custom-tests/:testId/mcqs/:mcqId     (delete one already-saved mcq)
 *                            GET    /api/custom-tests/:testId/mcqs/list       (resume: page in existing mcqs)
 *                            POST   /api/custom-tests/:testId/publish        → "published"
 *
 *   "published"         → Phase 2 (read-only, Publish button replaced by Published ✓)
 *
 * Heading: "[Group Name] — Test [Number]"   e.g. "Police — Test 1"
 * Back:    ← Dashboard  → /admin/dashboard
 */

import {
  useState,
  useEffect,
  useCallback,
  useRef,
  forwardRef,
  useImperativeHandle,
} from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../../api/axios";
import toast from "react-hot-toast";
import TimePicker from "../../components/admin/TimePicker";
import JsonMcqImportButton from "../../components/admin/JsonMcqImportButton";
import SubjectBreakdownEditor from "../../components/admin/SubjectBreakdownEditor";
import MarksSettingsEditor from "../../components/admin/MarksSettingsEditor";

// ─────────────────────────────────────────────────────────────
//  Shared helpers
// ─────────────────────────────────────────────────────────────

function Spinner({ size = "sm" }) {
  const cls = size === "sm" ? "w-3.5 h-3.5" : "w-5 h-5";
  return (
    <span
      className={`${cls} border-2 border-current border-t-transparent rounded-full animate-spin inline-block`}
    />
  );
}

/** Total seconds → { hours, minutes, seconds } for the TimePicker component */
function secondsToHMS(totalSecs) {
  const s = totalSecs || 0;
  return {
    hours:   Math.floor(s / 3600),
    minutes: Math.floor((s % 3600) / 60),
    seconds: s % 60,
  };
}

/** { hours, minutes, seconds } → total seconds */
function hmsToSeconds({ hours, minutes, seconds }) {
  return Number(hours) * 3600 + Number(minutes) * 60 + Number(seconds);
}

// ─────────────────────────────────────────────────────────────
//  Phase 1 — Settings
// ─────────────────────────────────────────────────────────────

function SettingsPhase({
  testId,
  initialSeconds,
  initialSubjectBreakdown = [],
  initialTotalMarks = "100",
  initialNegMarkEnabled = false,
  initialNegMarkValue = "0",
  isEdit = false,
  onSaved,
}) {
  const [timeHMS, setTimeHMS] = useState(secondsToHMS(initialSeconds || 1800));
  const [timeError, setTimeError] = useState("");
  const [subjectBreakdown, setSubjectBreakdown] = useState(initialSubjectBreakdown);
  const [totalMarks, setTotalMarks] = useState(String(initialTotalMarks ?? "100"));
  const [negMarkEnabled, setNegMarkEnabled] = useState(initialNegMarkEnabled);
  const [negMarkValue, setNegMarkValue] = useState(String(initialNegMarkValue ?? "0"));
  const [saving, setSaving] = useState(false);

  function handleMarksChange(patch) {
    if (patch.totalMarks !== undefined) setTotalMarks(patch.totalMarks);
    if (patch.negMarkEnabled !== undefined) setNegMarkEnabled(patch.negMarkEnabled);
    if (patch.negMarkValue !== undefined) setNegMarkValue(patch.negMarkValue);
  }

  async function handleSave() {
    let valid = true;

    const totalSecs = hmsToSeconds(timeHMS);
    if (totalSecs < 60) {
      setTimeError("Time limit must be at least 1 minute.");
      valid = false;
    } else {
      setTimeError("");
    }

    if (!valid) return;

    setSaving(true);
    try {
      const { data } = await api.patch(`/custom-tests/${testId}/settings`, {
        timeLimitSeconds: totalSecs,
        subjectBreakdown,
        totalMarks: parseFloat(totalMarks) || 100,
        negativeMarking: {
          enabled: negMarkEnabled,
          marksPerWrong: parseFloat(negMarkValue) || 0,
        },
      });
      // data: { saved, timeLimitSeconds, totalMcqs, subjectBreakdown, totalMarks, negativeMarking, status: "mcqs_pending" }
      toast.success("Settings saved.");
      onSaved({
        timeLimitSeconds: data.timeLimitSeconds,
        totalMcqs: data.totalMcqs,
        subjectBreakdown: data.subjectBreakdown,
        totalMarks: data.totalMarks,
        negativeMarking: data.negativeMarking,
        status: data.status, // "mcqs_pending" → triggers phase transition
      });
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to save settings.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <section className="bg-surface border border-border rounded-xl p-6 mb-6 shadow-sm">
      <h2 className="text-sm font-semibold text-txt-secondary uppercase tracking-widest mb-5">
        {isEdit ? "Edit Test Settings" : "Phase 1 Test Settings"}
      </h2>

      <div className="flex flex-col gap-6">
        {/* Time Limit */}
        <div>
          <label className="text-txt-secondary font-medium text-xs block mb-2">
            Time Limit <span className="text-danger">*</span>
          </label>
          <TimePicker
            hours={timeHMS.hours}
            minutes={timeHMS.minutes}
            seconds={timeHMS.seconds}
            onChange={setTimeHMS}
            error={timeError}
          />
          <p className="text-xs text-txt-muted mt-1.5">
            e.g. 00 : 30 : 00 for a 30-minute test
          </p>
        </div>

        {/* Subject % Breakdown */}
        <div>
          <label className="text-txt-secondary font-medium text-xs block mb-2">
            Subject Breakdown <span className="text-txt-muted normal-case">(optional)</span>
          </label>
          <p className="text-xs text-txt-muted mb-2">
            A test usually covers more than one subject — add each one and roughly
            what share of the test it makes up. Shown to users on the Start Test popup.
          </p>
          <SubjectBreakdownEditor value={subjectBreakdown} onChange={setSubjectBreakdown} />
        </div>

        {/* Marks & Negative Marking */}
        <div>
          <label className="text-txt-secondary font-medium text-xs block mb-2">
            Marks & Negative Marking
          </label>
          <MarksSettingsEditor
            totalMarks={totalMarks}
            negMarkEnabled={negMarkEnabled}
            negMarkValue={negMarkValue}
            onChange={handleMarksChange}
          />
        </div>

        {/* Save button */}
        <div>
          <button
            onClick={handleSave}
            disabled={saving}
            className="bg-brand hover:bg-brand-dark disabled:opacity-60 text-white text-sm font-semibold px-6 py-2.5 rounded-lg transition flex items-center gap-2"
          >
            {saving && <Spinner />}
            {saving ? "Saving…" : isEdit ? "Save Changes" : "Save Settings"}
          </button>
        </div>
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────
//  Phase 2 — MCQ Editor
// ─────────────────────────────────────────────────────────────

// Stable client-side identity for MCQs that don't have a server _id yet.
// Used only for React's `key` prop so a card's identity survives array
// shifts (e.g. deleting an earlier MCQ), instead of being tied to its
// position in the array.
let mcqClientKeySeq = 0;
function makeClientKey() {
  mcqClientKeySeq += 1;
  return `local-${Date.now()}-${mcqClientKeySeq}`;
}

function blankMcq() {
  return { clientKey: makeClientKey(), question: "", options: ["", "", "", ""], correctOption: 0 };
}

const OPTION_LETTERS = ["A", "B", "C", "D"];

/** A single MCQ is "complete" once the question + all 4 options are non-empty. */
function isMcqComplete(mcq) {
  if (!mcq || !mcq.question || !mcq.question.trim()) return false;
  if (!Array.isArray(mcq.options) || mcq.options.length !== 4) return false;
  return mcq.options.every((o) => o && o.trim());
}

// Small inline indicator shown next to an MCQ that's mid-edit, so autosave
// is visible instead of silent. "saved" auto-clears itself after a couple
// seconds (see savePatchedMcq), so it reads as a brief confirmation flash
// rather than a permanent label.
function EditStatusBadge({ status }) {
  if (status === "pending" || status === "saving") {
    return (
      <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide text-txt-muted">
        <Spinner /> Saving…
      </span>
    );
  }
  if (status === "saved") {
    return (
      <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide text-success">
        ✓ Saved
      </span>
    );
  }
  if (status === "error") {
    return (
      <span className="text-[10px] font-bold uppercase tracking-wide text-danger">
        Save failed
      </span>
    );
  }
  return null;
}

// `disabled` locks the question/option fields (used for MCQs that haven't
// been saved to the server yet — there's nothing to edit). `canDelete`
// controls the Remove button separately: once a test is published, editing
// existing MCQs (e.g. fixing a typo) stays allowed since it doesn't change
// how many MCQs the test has, but deleting is blocked because it would
// shrink mcqCount below what the published test's blueprint/generation
// already expects.
function McqCard({ index, mcq, onChange, onDelete, disabled, canDelete = !disabled, statusBadge, editStatus }) {
  return (
    <div className="bg-surface border border-border rounded-xl p-4 mb-3 shadow-sm">
      <div className="flex items-center justify-between mb-2">
        <p className="text-txt-muted text-sm">MCQ {index + 1}</p>
        <div className="flex items-center gap-3">
          {statusBadge}
          <EditStatusBadge status={editStatus} />
          {canDelete && (
            <button
              type="button"
              onClick={() => onDelete(index)}
              className="text-xs font-semibold text-danger hover:text-danger/80 transition"
              title="Delete this MCQ"
            >
              Remove
            </button>
          )}
        </div>
      </div>

      <textarea
        value={mcq.question}
        onChange={(e) => onChange(index, "question", e.target.value)}
        disabled={disabled}
        placeholder="Type the question here…"
        rows={2}
        className="w-full bg-surface border border-border text-txt-primary placeholder:text-txt-muted text-sm rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-brand transition resize-none mb-3 disabled:opacity-60"
      />

      <div className="space-y-2">
        {OPTION_LETTERS.map((letter, i) => (
          <div key={i} className="flex items-center gap-2">
            {/* Correct-option radio */}
            <button
              type="button"
              onClick={() => !disabled && onChange(index, "correctOption", i)}
              disabled={disabled}
              className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 transition ${
                mcq.correctOption === i
                  ? "ring-2 ring-success bg-success-light border-success"
                  : "border-border hover:border-txt-muted"
              } ${disabled ? "cursor-not-allowed opacity-60" : ""}`}
              title="Mark as correct"
            >
              {mcq.correctOption === i && (
                <span className="w-2.5 h-2.5 rounded-full bg-success" />
              )}
            </button>

            <span className="text-xs font-bold text-txt-muted w-4 shrink-0">{letter}</span>

            <input
              type="text"
              value={mcq.options[i]}
              onChange={(e) => {
                const opts = [...mcq.options];
                opts[i] = e.target.value;
                onChange(index, "options", opts);
              }}
              disabled={disabled}
              placeholder={`Option ${letter}`}
              className="flex-1 bg-surface border border-border text-txt-primary placeholder:text-txt-muted text-sm rounded-lg px-3 py-1.5 outline-none focus:ring-2 focus:ring-brand transition disabled:opacity-60"
            />
          </div>
        ))}
      </div>
    </div>
  );
}

// AUTOSAVE_CHUNK: MCQs are autosaved in multiples of this many at a time.
// The last partial chunk (< this many) only gets saved via the pre-publish
// flush, or the best-effort flush described below.
const AUTOSAVE_CHUNK = 10;
// How often the autosave interval checks whether a new chunk is ready.
const AUTOSAVE_INTERVAL_MS = 4000;
// Debounce delay before pushing an edit to an already-saved MCQ.
const EDIT_DEBOUNCE_MS = 700;

const McqPhase = forwardRef(function McqPhase(
  {
    testId,
    targetCount,
    initialMcqs,
    isPublished,
    timeLimitSeconds,
    subjectBreakdown,
    totalMarks,
    negativeMarking,
    onTargetCountChange,
  },
  ref
) {
  const navigate = useNavigate();
  // initialMcqs come from the server with a real `_id` already — reuse it
  // as the stable clientKey so keys never change once assigned.
  const [mcqs, setMcqs] = useState(() =>
    initialMcqs.map((m) => ({ ...m, clientKey: m.clientKey ?? m._id ?? makeClientKey() }))
  );

  // Number of MCQs already confirmed saved on the server (as individual Mcq
  // documents in the new collection). Everything at index < lastSavedIndex
  // is guaranteed to carry an `_id` — see the invariant note on
  // fetchAndMergeIds below.
  const [lastSavedIndex, setLastSavedIndex] = useState(initialMcqs.length);
  const [autosaving, setAutosaving] = useState(false);
  const [batchError, setBatchError] = useState("");
  const [publishing, setPublishing] = useState(false);

  // savingRef guards against overlapping autosave calls — if a save is
  // still in flight when the interval fires again, that tick is skipped.
  const savingRef = useRef(false);

  // Mirrors the latest mcqs/lastSavedIndex/isPublished into a ref so the
  // setInterval callback and debounced edit timers always read fresh
  // values instead of a stale closure.
  const stateRef = useRef({ mcqs, lastSavedIndex, isPublished });
  stateRef.current = { mcqs, lastSavedIndex, isPublished };

  // Source of truth for "how much has already been sent to the server",
  // separate from the `lastSavedIndex` STATE above. This is a plain ref
  // updated SYNCHRONOUSLY the moment a batch is claimed — before the
  // network call even starts — so it can never go stale the way
  // stateRef.current can when a component unmounts before its next
  // render (e.g. navigate() right after an autosave resolves). Without
  // this, the unmount-flush effect below can read a pre-save
  // stateRef.current.lastSavedIndex and re-send a batch that was
  // already saved, creating duplicate Mcq documents.
  const flushedUpToRef = useRef(initialMcqs.length);

  // index → pending debounce timer id, for single-MCQ PATCH edits.
  const editTimersRef = useRef({});

  const mcqCount = mcqs.length;
  const progressPct = targetCount ? Math.min(100, Math.round((lastSavedIndex / targetCount) * 100)) : 0;
  const canAddMore = mcqCount < targetCount;
  const canPublish = mcqCount >= targetCount && targetCount > 0;

  function handleAddBatch() {
    if (!canAddMore) return;
    const toAdd = Math.min(AUTOSAVE_CHUNK, targetCount - mcqCount);
    setMcqs((prev) => [...prev, ...Array(toAdd).fill(null).map(blankMcq)]);
  }

  // index → "pending" | "saving" | "saved" | "error", purely for the small
  // status indicator next to each MCQ so an edit's autosave is visible
  // instead of silent (it previously only surfaced a toast on failure).
  const [editStatus, setEditStatus] = useState({});

  // ── Editing ────────────────────────────────────────────────
  const handleChange = useCallback((index, field, value) => {
    setMcqs((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });

    // If this MCQ was already autosaved, don't wait for the next bulk
    // autosave tick — debounce a single-MCQ PATCH instead.
    if (index < stateRef.current.lastSavedIndex) {
      setEditStatus((s) => ({ ...s, [index]: "pending" }));
      if (editTimersRef.current[index]) clearTimeout(editTimersRef.current[index]);
      editTimersRef.current[index] = setTimeout(() => {
        delete editTimersRef.current[index];
        savePatchedMcq(index);
      }, EDIT_DEBOUNCE_MS);
    }
  }, []);

  async function savePatchedMcq(index) {
    const { mcqs: currentMcqs } = stateRef.current;
    const mcq = currentMcqs[index];
    if (!mcq || !mcq._id) return; // not actually persisted yet — skip silently
    if (!isMcqComplete(mcq)) return; // don't push a half-edited MCQ
    setEditStatus((s) => ({ ...s, [index]: "saving" }));
    try {
      await api.patch(`/custom-tests/${testId}/mcqs/${mcq._id}`, {
        question: mcq.question,
        options: mcq.options,
        correctOption: mcq.correctOption,
      });
      setEditStatus((s) => ({ ...s, [index]: "saved" }));
      setTimeout(() => {
        setEditStatus((s) => (s[index] === "saved" ? { ...s, [index]: undefined } : s));
      }, 2000);
    } catch (err) {
      setEditStatus((s) => ({ ...s, [index]: "error" }));
      toast.error(err.response?.data?.message || "Failed to save your edit.");
    }
  }

  // ── Deleting ───────────────────────────────────────────────
  async function handleDelete(index) {
    const { mcqs: currentMcqs, lastSavedIndex: savedIdx } = stateRef.current;
    const mcq = currentMcqs[index];
    if (!mcq) return;

    if (editTimersRef.current[index]) {
      clearTimeout(editTimersRef.current[index]);
      delete editTimersRef.current[index];
    }

    if (index < savedIdx) {
      if (!mcq._id) {
        toast.error("This MCQ is still being saved — try again in a moment.");
        return;
      }
      try {
        await api.delete(`/custom-tests/${testId}/mcqs/${mcq._id}`);
      } catch (err) {
        toast.error(err.response?.data?.message || "Failed to delete this MCQ.");
        return;
      }
      setMcqs((prev) => prev.filter((_, i) => i !== index));
      setLastSavedIndex((prev) => prev - 1);
      toast.success("MCQ deleted.");
    } else {
      // Never persisted — just drop it locally, no API call needed.
      setMcqs((prev) => prev.filter((_, i) => i !== index));
    }
  }

  // ── Autosave core ────────────────────────────────────────────
  function isBatchReady(upTo) {
    const { mcqs: currentMcqs } = stateRef.current;
    for (let i = 0; i < upTo; i++) {
      if (!isMcqComplete(currentMcqs[i])) return false;
    }
    return true;
  }

  // GET .../mcqs/list returns Mcq documents (with _id) sorted by `order`.
  // We always re-fetch from the start up to `upTo` rather than trying to
  // compute an exact skip/limit for just the new slice — the paginated
  // endpoint's skip is derived from page*limit, so this is the simplest
  // way to reliably land on the new items regardless of chunk alignment
  // (e.g. after a partial pre-publish flush). Cost scales with `upTo`,
  // which is fine for the typical size of these tests.
  async function fetchAndMergeIds(upTo) {
    const { data } = await api.get(`/custom-tests/${testId}/mcqs/list`, {
      params: { page: 1, limit: upTo },
    });
    const docs = data.mcqs || [];
    setMcqs((prev) =>
      prev.map((m, i) => (i < upTo && docs[i] ? { ...m, _id: docs[i]._id } : m))
    );
  }

  // Sends mcqs[startIdx, batchEnd) to the bulk-add endpoint, then merges
  // back the resulting _ids before advancing lastSavedIndex — so the
  // invariant "index < lastSavedIndex ⇒ mcqs[index]._id is set" always
  // holds for any code that runs after this resolves.
  async function doAutosave(batchEnd) {
    const { mcqs: currentMcqs } = stateRef.current;
    // Read the start index from the ref, not from state — see the note
    // on flushedUpToRef above. If another caller already claimed (or is
    // claiming) this range, bail out instead of re-sending it.
    const startIdx = flushedUpToRef.current;
    if (batchEnd <= startIdx) return true;

    const newSlice = currentMcqs.slice(startIdx, batchEnd).map((m) => ({
      question: m.question,
      options: m.options,
      correctOption: m.correctOption,
    }));
    if (newSlice.length === 0) return true;

    // Claim this range immediately, synchronously, before the request
    // even goes out — this is what makes a second concurrent/late flush
    // (e.g. from the unmount cleanup effect) a safe no-op instead of a
    // duplicate insert.
    flushedUpToRef.current = batchEnd;

    savingRef.current = true;
    setAutosaving(true);
    try {
      await api.post(`/custom-tests/${testId}/mcqs/batch`, { mcqs: newSlice });
      await fetchAndMergeIds(batchEnd);
      setLastSavedIndex(batchEnd);
      setBatchError("");
      return true;
    } catch (err) {
      // Roll back the claim so a genuine retry (interval tick, manual
      // retry, next flush) can still send this range.
      flushedUpToRef.current = startIdx;
      setBatchError(err.response?.data?.message || "Autosave failed — will retry shortly.");
      return false;
    } finally {
      savingRef.current = false;
      setAutosaving(false);
    }
  }

  function tryAutosave() {
    if (stateRef.current.isPublished) return;
    if (savingRef.current) return; // a save is already in flight — skip this tick
    const { mcqs: currentMcqs } = stateRef.current;
    const startIdx = flushedUpToRef.current;
    const availableNew = currentMcqs.length - startIdx;
    if (availableNew < AUTOSAVE_CHUNK) return;
    const batchEnd = startIdx + Math.floor(availableNew / AUTOSAVE_CHUNK) * AUTOSAVE_CHUNK;
    if (!isBatchReady(batchEnd)) return; // not fully filled in yet — wait for next tick
    doAutosave(batchEnd);
  }

  useEffect(() => {
    const id = setInterval(tryAutosave, AUTOSAVE_INTERVAL_MS);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function waitForInFlightSave(maxMs = 10000) {
    const start = Date.now();
    while (savingRef.current && Date.now() - start < maxMs) {
      await new Promise((r) => setTimeout(r, 150));
    }
  }

  // Flushes any remaining unsaved-but-complete MCQs (even fewer than 10),
  // used before publish and as the best-effort "navigating away" flush.
  async function flushRemaining() {
    await waitForInFlightSave();
    const { mcqs: currentMcqs } = stateRef.current;
    const startIdx = flushedUpToRef.current;
    const target = currentMcqs.length;
    if (target - startIdx <= 0) return true;
    if (!isBatchReady(target)) {
      const msg = "Fill in every question and all 4 options before publishing.";
      setBatchError(msg);
      toast.error(msg);
      return false;
    }
    return doAutosave(target);
  }

  useImperativeHandle(ref, () => ({ flushRemaining }));

  // ── Flush on navigating away ─────────────────────────────────
  // Case 1: in-app route change (e.g. another nav link) unmounts this
  // component without a full page unload. Best-effort, not awaited by the
  // unmounting caller — it can still be interrupted if the tab closes
  // immediately after, which is what the beforeunload handler below and
  // the explicit flush in the "← Dashboard" button are for.
  useEffect(() => {
    return () => {
      Object.values(editTimersRef.current).forEach(clearTimeout);
      flushRemaining().catch(() => {});
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Case 2: real page unload (tab close, refresh, typed URL). We cannot
  // await anything here, so this is fired without waiting for a response
  // using fetch(..., { keepalive: true }), which lets the request survive
  // past unload in most modern browsers. IMPORTANT CAVEATS — this is a
  // genuine best-effort, not a guaranteed flush: there is no way to know
  // whether it actually completed, it cannot be retried on failure, and
  // keepalive requests share a combined ~64KB body budget so a very large
  // final chunk could be dropped. Auth relies on `withCredentials`
  // cookies, which `credentials: "include"` below preserves.
  useEffect(() => {
    function handleBeforeUnload() {
      const { mcqs: currentMcqs, isPublished: pub } = stateRef.current;
      if (pub) return;
      if (savingRef.current) return; // an autosave is already mid-flight, let it run
      const startIdx = flushedUpToRef.current;
      const target = currentMcqs.length;
      if (target - startIdx <= 0) return;
      if (!isBatchReady(target)) return; // don't ship incomplete MCQs

      const newSlice = currentMcqs.slice(startIdx, target).map((m) => ({
        question: m.question,
        options: m.options,
        correctOption: m.correctOption,
      }));
      // Claim the range immediately — this is a fire-and-forget beacon,
      // there's no response to await, so mark it saved optimistically so
      // nothing else re-sends it if the page happens to stay alive.
      flushedUpToRef.current = target;
      try {
        fetch(`${api.defaults.baseURL}/custom-tests/${testId}/mcqs/batch`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          keepalive: true,
          body: JSON.stringify({ mcqs: newSlice }),
        });
      } catch {
        /* best-effort only — nothing more we can do during unload */
      }
    }

    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, [testId]);

  async function handlePublish() {
    const flushed = await flushRemaining();
    if (!flushed) return;

    setPublishing(true);
    try {
      await api.post(`/custom-tests/${testId}/publish`);
      toast.success("Test published!");
      navigate("/admin/dashboard");
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to publish.");
    } finally {
      setPublishing(false);
    }
  }

  // ── JSON bulk import ─────────────────────────────────────────
  // The imported file's own length always wins   if it doesn't match
  // targetCount, the test's settings are updated on the server first so
  // publishing later isn't blocked by a stale expected count.
  //
  // NOTE: the new bulk-add endpoint only ever APPENDS Mcq documents — it
  // no longer replaces a full array the way the old endpoint did. That
  // makes JSON import only safe to use before anything has been
  // autosaved for this test (otherwise it would create duplicates
  // alongside the already-saved MCQs). We guard against that case below
  // rather than silently corrupting the test's MCQ list.
  async function handleJsonImport(importedMcqs) {
    if (flushedUpToRef.current > 0 || stateRef.current.lastSavedIndex > 0) {
      throw new Error(
        "JSON import can only be used before any MCQs have been autosaved for this test (bulk-add only appends, it can't replace what's already saved)."
      );
    }

    const newCount = importedMcqs.length;

    if (newCount !== targetCount) {
      try {
        await api.patch(`/custom-tests/${testId}/settings`, {
          timeLimitSeconds: timeLimitSeconds,
          totalMcqs: newCount,
          // Include the settings already saved in Phase 1 — the server
          // save endpoint overwrites these fields unconditionally, so
          // omitting them here was silently wiping out the admin-entered
          // subject breakdown (and resetting marks/negative marking to
          // their defaults) every time a JSON import's MCQ count didn't
          // match the target count.
          subjectBreakdown,
          totalMarks,
          negativeMarking,
        });
        onTargetCountChange(newCount);
      } catch (err) {
        throw new Error(
          err.response?.data?.message || "Could not update the MCQ count on the server."
        );
      }
    }

    try {
      await api.post(`/custom-tests/${testId}/mcqs/batch`, { mcqs: importedMcqs });
    } catch (err) {
      throw new Error(err.response?.data?.message || "Could not save the imported MCQs.");
    }

    flushedUpToRef.current = importedMcqs.length;
    setMcqs(importedMcqs.map((m) => ({ ...m })));
    await fetchAndMergeIds(importedMcqs.length);
    setLastSavedIndex(importedMcqs.length);
    setBatchError("");
    toast.success(`Imported ${importedMcqs.length} MCQs from JSON.`);
  }

  const batchCount = Math.ceil(mcqs.length / AUTOSAVE_CHUNK);

  return (
    <section>
      {/* Progress bar + Publish */}
      <div className="bg-surface border border-border rounded-xl p-6 mb-6 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-txt-secondary uppercase tracking-widest">
            Phase 2 MCQs
          </h2>
          <div className="flex items-center gap-3">
            {isPublished ? (
              <span className="flex items-center gap-1.5 text-sm font-semibold text-green-800 px-4 py-2 bg-success-light rounded-lg">
                ✓ Published
              </span>
            ) : (
              <button
                onClick={handlePublish}
                disabled={!canPublish || publishing}
                className={`flex items-center gap-2 text-sm font-semibold px-5 py-2 rounded-lg transition ${
                  canPublish
                    ? "bg-success hover:bg-green-700 text-white"
                    : "bg-bg text-txt-muted cursor-not-allowed"
                }`}
              >
                {publishing && <Spinner />}
                {publishing ? "Publishing…" : "Publish Test"}
              </button>
            )}
          </div>
        </div>

        {/* Progress bar — "X of [Total] MCQs Saved" */}
        <p className="text-txt-secondary text-sm mb-2 flex items-center gap-2">
          {lastSavedIndex} of {targetCount} MCQs Saved
          {autosaving && (
            <span className="inline-flex items-center gap-1 text-xs text-txt-muted">
              <Spinner /> Autosaving…
            </span>
          )}
        </p>
        {isPublished && (
          <p className="text-xs text-txt-muted mb-1">
            This test is live. You can still fix a question, option, or correct
            answer below — edits save automatically a few seconds after you stop
            typing. Adding or removing MCQs is locked once published.
          </p>
        )}
        <div className="flex items-center gap-3">
          <div className="flex-1 bg-bg rounded-full h-2 overflow-hidden">
            <div
              className="h-full bg-success rounded-full transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          <span className="text-sm font-semibold text-txt-secondary shrink-0 tabular-nums">
            {lastSavedIndex} / {targetCount}
          </span>
        </div>
      </div>

      {/* MCQ editor */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm font-semibold text-txt-secondary uppercase tracking-widest">
          MCQ Editor
        </h2>
        <button
          onClick={handleAddBatch}
          disabled={!canAddMore || isPublished}
          className={`flex items-center gap-2 text-sm font-semibold px-4 py-2 rounded-lg transition ${
            canAddMore && !isPublished
              ? "bg-brand-light hover:bg-brand/20 text-brand border border-brand/30"
              : "bg-bg text-txt-muted cursor-not-allowed"
          }`}
        >
          <span className="text-base leading-none">+</span>
          Add MCQs
          {canAddMore && (
            <span className="text-xs opacity-60">
              ({Math.min(AUTOSAVE_CHUNK, targetCount - mcqCount)} more)
            </span>
          )}
        </button>
      </div>

      {batchError && (
        <p className="text-xs text-danger bg-danger-light border border-danger/20 rounded-lg px-3 py-2 mb-4">
          {batchError}
        </p>
      )}

      {!isPublished && (
        <div className="mb-5 bg-bg/60 border border-border rounded-xl p-4">
          <p className="text-xs text-txt-muted mb-2">
            Upload a JSON file to fill in every MCQ automatically   the number of
            questions created will match the file, no matter what count is set above.
            Only available before any MCQs have been autosaved for this test.
          </p>
          <JsonMcqImportButton mode="customTest" onImport={handleJsonImport} />
        </div>
      )}

      {mcqs.length === 0 ? (
        <div className="text-center py-10 text-txt-muted text-sm border border-dashed border-border rounded-xl">
          Click "Add MCQs" to start adding questions.
        </div>
      ) : (
        Array.from({ length: batchCount }).map((_, batchIndex) => {
          const batchStart = batchIndex * AUTOSAVE_CHUNK;
          const batchEnd   = Math.min(batchStart + AUTOSAVE_CHUNK, mcqs.length);
          const batchSaved = batchEnd <= lastSavedIndex;
          const batchSlice = mcqs.slice(batchStart, batchEnd);

          return (
            <div key={batchIndex} className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-semibold text-txt-muted">
                  Batch {batchIndex + 1} ({batchStart + 1}–{batchEnd})
                </p>
                {!isPublished && (
                  batchSaved ? (
                    <span className="text-xs font-semibold text-success flex items-center gap-1">
                      ✓ Saved
                    </span>
                  ) : autosaving ? (
                    <span className="text-xs font-semibold text-txt-muted flex items-center gap-1">
                      <Spinner /> Saving…
                    </span>
                  ) : (
                    <span className="text-xs text-txt-muted">
                      Autosaves automatically once complete
                    </span>
                  )
                )}
              </div>

              {batchSlice.map((mcq, i) => {
                const index = batchStart + i;
                const saved = index < lastSavedIndex;
                return (
                  <McqCard
                    key={mcq.clientKey ?? index}
                    index={index}
                    mcq={mcq}
                    onChange={handleChange}
                    onDelete={handleDelete}
                    disabled={false}
                    canDelete={!isPublished}
                    editStatus={editStatus[index]}
                    statusBadge={
                      saved ? (
                        <span className="text-[10px] font-bold uppercase tracking-wide text-success">
                          Saved
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold uppercase tracking-wide text-txt-muted">
                          Draft
                        </span>
                      )
                    }
                  />
                );
              })}
            </div>
          );
        })
      )}
    </section>
  );
});

// ─────────────────────────────────────────────────────────────
//  Main page
// ─────────────────────────────────────────────────────────────

export default function AdminCustomTestPage() {
  const { testId } = useParams();
  const navigate   = useNavigate();

  const [test, setTest]         = useState(null);
  const [savedMcqs, setSavedMcqs] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [loadError, setLoadError] = useState("");
  const [showSettingsEditor, setShowSettingsEditor] = useState(false);

  const mcqPhaseRef = useRef(null);

  // Fetch test on mount
  useEffect(() => {
    async function fetchTest() {
      try {
        const { data } = await api.get(`/custom-tests/test/${testId}`);
        setTest(data);

        // Stage 3: MCQs now live in their own collection, not test.mcqs
        // (that embedded array was removed from the schema in Stage 1).
        // Resume by paging them in via the new list endpoint, requesting
        // a large page size so an in-progress test's MCQs load in one call.
        if (data.status && data.status !== "settings_pending") {
          const { data: mcqData } = await api.get(`/custom-tests/${testId}/mcqs/list`, {
            params: { page: 1, limit: 100000 },
          });
          setSavedMcqs(
            (mcqData.mcqs || []).map((m) => ({
              _id: m._id,
              question: m.question,
              options: m.options,
              correctOption: m.correctOption,
            }))
          );
        }
      } catch (err) {
        setLoadError(err.response?.data?.message || "Failed to load test.");
      } finally {
        setLoading(false);
      }
    }
    fetchTest();
  }, [testId]);

  // Called by SettingsPhase after a successful PATCH
  // Merges the server response fields into local test state → triggers phase change
  function handleSettingsSaved({ timeLimitSeconds, totalMcqs, subjectBreakdown, totalMarks, negativeMarking, status }) {
    setTest((prev) => ({ ...prev, timeLimitSeconds, totalMcqs, subjectBreakdown, totalMarks, negativeMarking, status }));
    setShowSettingsEditor(false); // collapse back down after a later-phase edit
  }

  // Called after a JSON import changes totalMcqs on the server, so the
  // progress bar / publish-eligibility above keep using the right target.
  function handleTargetCountChange(newCount) {
    setTest((prev) => ({ ...prev, totalMcqs: newCount }));
  }

  // Flushes any pending autosaves before leaving the page via the in-app
  // "Dashboard" link — the one navigation path we can reliably await.
  async function handleBackToDashboard() {
    if (mcqPhaseRef.current?.flushRemaining) {
      await mcqPhaseRef.current.flushRemaining();
    }
    navigate("/admin/dashboard");
  }

  // ── Loading / error states ────────────────────────────────

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto py-16 flex justify-center">
        <Spinner size="lg" />
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="max-w-3xl mx-auto py-12">
        <p className="text-danger text-sm mb-3">{loadError}</p>
        <button
          onClick={() => navigate("/admin/dashboard")}
          className="text-sm text-brand hover:text-brand-dark transition"
        >
          ← Back to Dashboard
        </button>
      </div>
    );
  }

  // ── Derived display values ────────────────────────────────

  // Heading: "[Group Name] — Test [Number]"
  const heading = `${test.groupName || "Custom"} Test ${test.testNumber}`;

  const status     = test.status; // "settings_pending" | "mcqs_pending" | "in_progress" | "published"
  const isPhase1   = status === "settings_pending";
  const isPublished = status === "published";

  // ── Render ────────────────────────────────────────────────

  return (
    <div className="max-w-3xl mx-auto">
      {/* Page header */}
      <div className="mb-8">
        <button
          onClick={handleBackToDashboard}
          className="text-xs text-txt-muted hover:text-txt-primary transition mb-3 inline-flex items-center gap-1"
        >
          ← Dashboard
        </button>

        <h1 className="text-2xl font-bold text-txt-primary">{heading}</h1>

        <p className="text-txt-secondary text-sm mt-1">
          {isPublished
            ? "This test is published and live to users."
            : isPhase1
            ? "Set the time limit and MCQ count to get started."
            : "Add MCQs, then publish when ready."}
        </p>
      </div>

      {/* Phase 1 — Settings (only when status === "settings_pending") */}
      {isPhase1 && (
        <SettingsPhase
          testId={testId}
          initialSeconds={test.timeLimitSeconds}
          onSaved={handleSettingsSaved}
        />
      )}

      {/* Phase 2 — MCQ editor (all statuses except settings_pending) */}
      {!isPhase1 && (
        <div className="mb-6">
          <button
            type="button"
            onClick={() => setShowSettingsEditor((v) => !v)}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-txt-secondary hover:text-txt-primary border border-border hover:border-txt-muted rounded-lg px-3 py-2 transition"
          >
            ⚙ {showSettingsEditor ? "Hide Settings Editor" : "Edit Test Settings (Time Limit, Subject Breakdown, Marks)"}
          </button>
          {showSettingsEditor && (
            <div className="mt-4">
              <SettingsPhase
                testId={testId}
                initialSeconds={test.timeLimitSeconds}
                initialSubjectBreakdown={test.subjectBreakdown || []}
                initialTotalMarks={test.totalMarks}
                initialNegMarkEnabled={test.negativeMarking?.enabled || false}
                initialNegMarkValue={test.negativeMarking?.marksPerWrong}
                isEdit
                onSaved={handleSettingsSaved}
              />
            </div>
          )}
        </div>
      )}

      {!isPhase1 && (
        <McqPhase
          ref={mcqPhaseRef}
          testId={testId}
          targetCount={test.totalMcqs || 0}
          initialMcqs={savedMcqs}
          isPublished={isPublished}
          timeLimitSeconds={test.timeLimitSeconds}
          subjectBreakdown={test.subjectBreakdown || []}
          totalMarks={test.totalMarks}
          negativeMarking={test.negativeMarking}
          onTargetCountChange={handleTargetCountChange}
        />
      )}
    </div>
  );
}