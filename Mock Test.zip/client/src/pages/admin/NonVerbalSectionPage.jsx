/**
 * NonVerbalSectionPage.jsx  (Part 4 Prompt 10)
 *
 * Prompt 10 additions over Prompt 05:
 *   - useBlocker (React Router v6.4+) blocks in-app navigation when isDirty
 *   - useBeforeUnload warns on tab close / browser refresh when isDirty
 *   - Auto-save failure banner with Retry button
 *   - Wrapped in AdminErrorBoundary (see export at bottom)
 *
 * Route: /admin/dashboard/category/:slug/test/:testId/add-nonverbal
 */

import { useParams, Link, useNavigate, useLocation, useBlocker } from "react-router-dom";
import { useEffect } from "react";
import TimePicker from "../../components/admin/TimePicker";
import MCQList from "../../components/admin/MCQList";
import JsonMcqImportButton from "../../components/admin/JsonMcqImportButton";
import useSectionPage from "../../hooks/useSectionPage";
import SubjectBreakdownEditor from "../../components/admin/SubjectBreakdownEditor";
import AdminErrorBoundary from "../../components/admin/AdminErrorBoundary";

// ── Helpers ───────────────────────────────────────────────────

function createEmptyMcq(saved) {
  if (!saved) {
    return {
      question:      "",
      options:       ["", "", "", ""],
      correctIndex:  -1,
      explanation:   "",
      imageUrl:      "",
      imagePublicId: "",
    };
  }
  return {
    question:      saved.question     || "",
    options:       saved.options?.length === 4 ? saved.options : ["", "", "", ""],
    correctIndex:  typeof saved.correctIndex === "number" ? saved.correctIndex : -1,
    explanation:   saved.explanation  || "",
    imageUrl:      saved.imageUrl     || "",
    imagePublicId: saved.imagePublicId || "",
  };
}

function isMcqComplete(m) {
  return (
    m.imageUrl?.trim().length > 0 &&
    Array.isArray(m.options) &&
    m.options.every((o) => o?.trim().length > 0) &&
    typeof m.correctIndex === "number" &&
    m.correctIndex >= 0
  );
}

// ── Icons ─────────────────────────────────────────────────────

function ChevronRightIcon() {
  return (
    <svg className="w-3.5 h-3.5 text-txt-muted" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
    </svg>
  );
}

function SaveIcon() {
  return (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
        d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
    </svg>
  );
}

function Spinner() {
  return (
    <svg className="w-3.5 h-3.5 animate-spin" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
    </svg>
  );
}

// ── Section step wrapper ──────────────────────────────────────

function StepCard({ id, number, title, description, children }) {
  return (
    <div id={id} className="bg-surface/60 border border-border rounded-2xl overflow-hidden">
      <div className="px-6 py-4 border-b border-border/60 bg-surface/80 flex items-start gap-4">
        <span className="flex-shrink-0 w-7 h-7 rounded-full bg-accent text-white text-xs font-extrabold flex items-center justify-center mt-0.5">
          {number}
        </span>
        <div>
          <h2 className="text-txt-primary font-semibold text-base">{title}</h2>
          {description && <p className="text-txt-muted text-xs mt-0.5">{description}</p>}
        </div>
      </div>
      <div className="px-6 py-5">{children}</div>
    </div>
  );
}

// ── Reduce-count warning dialog ───────────────────────────────

function ReduceCountDialog({ removeCount, onConfirm, onCancel }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-surface border border-border rounded-2xl p-6 max-w-sm w-full shadow-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-9 h-9 rounded-full bg-amber-400/10 border border-amber-400/20 flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                d="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
            </svg>
          </div>
          <h3 className="text-txt-primary font-semibold text-base">Reduce MCQ Count?</h3>
        </div>
        <p className="text-txt-secondary text-sm mb-5">
          Reducing the count will remove the last{" "}
          <span className="text-txt-primary font-semibold">{removeCount}</span> container
          {removeCount !== 1 ? "s" : ""}. Any data entered in those containers will be lost. Proceed?
        </p>
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="flex-1 border border-border text-txt-secondary hover:text-txt-primary hover:border-txt-muted text-sm font-medium px-4 py-2.5 rounded-lg transition-colors focus:outline-none"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 bg-amber-500 hover:bg-amber-400 text-white text-sm font-semibold px-4 py-2.5 rounded-lg transition-colors focus:outline-none"
          >
            Remove Containers
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Leave-page confirmation dialog (useBlocker) ───────────────

function LeavePageDialog({ onConfirm, onCancel }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-surface border border-border rounded-2xl p-6 max-w-sm w-full shadow-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-9 h-9 rounded-full bg-danger-light/10 border border-danger/20 flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-danger" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                d="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
            </svg>
          </div>
          <h3 className="text-txt-primary font-semibold text-base">Unsaved Changes</h3>
        </div>
        <p className="text-txt-secondary text-sm mb-5">
          You have unsaved changes. Leave without saving?
        </p>
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="flex-1 border border-border text-txt-secondary hover:text-txt-primary hover:border-txt-muted text-sm font-medium px-4 py-2.5 rounded-lg transition-colors focus:outline-none"
          >
            Stay on Page
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 bg-danger hover:bg-red-700 text-white text-sm font-semibold px-4 py-2.5 rounded-lg transition-colors focus:outline-none"
          >
            Leave Anyway
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Auto-save failure banner ──────────────────────────────────

function AutoSaveFailedBanner({ onRetry }) {
  return (
    <div className="flex items-center justify-between gap-4 bg-danger-light/10 border border-danger/30 rounded-xl px-4 py-3">
      <div className="flex items-center gap-2.5">
        <svg className="w-4 h-4 text-danger flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
            d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <p className="text-sm text-red-300">
          <span className="font-semibold">Auto-save failed.</span> Your changes are not saved. Try again or copy your work before leaving.
        </p>
      </div>
      <button
        onClick={onRetry}
        className="flex-shrink-0 text-xs font-semibold text-red-300 border border-danger/40 hover:border-danger/70 hover:text-red-200 px-3 py-1.5 rounded-lg transition-colors"
      >
        Retry
      </button>
    </div>
  );
}

// ── Page skeleton ─────────────────────────────────────────────

function PageSkeleton() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-8 space-y-6 animate-pulse">
      <div className="h-3 w-48 bg-bg rounded" />
      <div className="h-8 w-64 bg-bg rounded" />
      {[1, 2, 3].map((n) => (
        <div key={n} className="bg-surface/60 border border-border rounded-2xl h-32" />
      ))}
    </div>
  );
}

// ── Inner page (wrapped by error boundary below) ──────────────

function NonVerbalSectionPageInner() {
  const { slug, testId } = useParams();
  const navigate         = useNavigate();
  const location         = useLocation();

  const {
    loading, loadError,
    time, timeError, totalSeconds,
    totalMCQs, mcqCountNum,
    pendingCount, showReduceDialog,
    subjectBreakdown,
    mcqs,
    saveStatus, isFinalSaving, finalSaveError, erroredMcqIndex,
    canSave,
    isDirty,
    autoSaveFailed,
    retryAutoSave,
    handleTimeChange,
    handleCountChange,
    handleReduceConfirm,
    handleReduceCancel,
    handleSubjectBreakdownChange,
    handleMcqsChange,
    handleSingleMcqEdit,
    handleAddMcqBatch,
    handleJsonImport,
    handleSaveSection,
  } = useSectionPage({
    type:          "nonverbal",
    testId,
    slug,
    navigate,
    createEmptyMcq,
    isMcqComplete,
    successToast:  "Non-Verbal section saved. Academic section is now available.",
  });

  // ── useBlocker: block in-app nav when isDirty ────────────
  const blocker = useBlocker(isDirty);

  // ── useBeforeUnload: warn on tab close / refresh ─────────
  useEffect(() => {
    function handleBeforeUnload(e) {
      if (!isDirty) return;
      e.preventDefault();
      e.returnValue = "";
    }
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, [isDirty]);

  // ── Arriving from the admin "Edit" dropdown: jump straight to the
  // MCQ containers instead of landing on the Timer step at the top,
  // since editing existing questions is the whole point of that flow.
  useEffect(() => {
    if (!loading && location.state?.fromEdit) {
      requestAnimationFrame(() => {
        document
          .getElementById("mcq-containers-step")
          ?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    }
  }, [loading, location.state]);

  if (loading) return <PageSkeleton />;

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 space-y-6">

      {/* ── Breadcrumb ──────────────────────────────────────── */}
      <nav className="flex items-center gap-1.5 text-xs text-txt-muted" aria-label="Breadcrumb">
        <Link to="/admin/dashboard" className="hover:text-txt-secondary transition-colors">Home</Link>
        <ChevronRightIcon />
        <Link to={`/admin/dashboard/category/${slug}`} className="hover:text-txt-secondary transition-colors">
          {slug}
        </Link>
        <ChevronRightIcon />
        <span className="text-txt-secondary font-medium">Add Non-Verbal Section</span>
      </nav>

      {/* ── Prominent backend validation error banner (Prompt 99) ── */}
      {finalSaveError && (
        <div className="bg-danger-light/10 border border-danger/30 rounded-xl px-4 py-3.5 flex items-start gap-3">
          <svg className="w-5 h-5 text-danger flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
              d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <div>
            <p className="text-sm font-semibold text-red-300">Could not save section</p>
            <p className="text-sm text-red-300/90 mt-0.5">{finalSaveError}</p>
          </div>
        </div>
      )}

      {/* ── Page header ──────────────────────────────────────── */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-black">Non-Verbal Section</h1>
          <p className="text-txt-muted text-sm mt-0.5">
            Test ID:{" "}
            <code className="text-amber-600 text-xs bg-bg px-1.5 py-0.5 rounded">
              {testId}
            </code>
          </p>
        </div>

        {/* Save status + top save button */}
        <div className="flex flex-col items-end gap-2">
          <div className="flex items-center gap-3">
            {saveStatus === "saving" && (
              <span className="flex items-center gap-1.5 text-xs text-txt-secondary">
                <Spinner /> Saving…
              </span>
            )}
            {saveStatus === "saved" && (
              <span className="flex items-center gap-1.5 text-xs text-success">
                <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
                Saved
              </span>
            )}
            {saveStatus === "error" && (
              <span className="text-xs text-danger">Auto-save failed</span>
            )}

            <button
              onClick={handleSaveSection}
              disabled={!canSave || isFinalSaving}
              title={!canSave ? "Every MCQ must have an image and a correct answer selected" : ""}
              className="inline-flex items-center gap-2 bg-accent hover:bg-accent-dark disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-semibold px-4 py-2.5 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-accent/50"
            >
              {isFinalSaving ? <Spinner /> : <SaveIcon />}
              {isFinalSaving ? "Saving…" : "Save Non-Verbal Section"}
            </button>
          </div>

          {finalSaveError && (
            <p className="text-xs text-danger text-right max-w-xs">{finalSaveError}</p>
          )}
        </div>
      </div>

      {/* ── Auto-save failure banner ─────────────────────────── */}
      {autoSaveFailed && <AutoSaveFailedBanner onRetry={retryAutoSave} />}

      {/* Draft load warning */}
      {loadError && (
        <div className="text-xs text-amber-400 bg-amber-400/10 border border-amber-400/20 rounded-lg px-4 py-2.5">
          {loadError}
        </div>
      )}

      {/* ── Step 1: Time Setting ─────────────────────────────── */}
      <StepCard
        number="1"
        title="Time Setting"
        description="Set the total time allowed for the non-verbal section."
      >
        <TimePicker
          hours={time.hours}
          minutes={time.minutes}
          seconds={time.seconds}
          onChange={handleTimeChange}
          error={timeError}
        />
        {totalSeconds >= 60 && (
          <p className="mt-3 text-xs text-txt-muted">
            Total:{" "}
            <span className="text-txt-secondary font-medium">
              {time.hours > 0 && `${time.hours}h `}
              {time.minutes > 0 && `${time.minutes}m `}
              {time.seconds > 0 && `${time.seconds}s`}
            </span>
            {" "}({totalSeconds} seconds)
          </p>
        )}
      </StepCard>

      {/* ── Step 2: MCQ Count ────────────────────────────────── */}
      <StepCard
        number="2"
        title="Total MCQ Count"
        description="How many questions should this non-verbal section contain?"
      >
        <div className="flex items-center gap-4">
          <input
            type="number"
            min="1"
            max="200"
            value={totalMCQs}
            onChange={handleCountChange}
            placeholder="e.g. 20"
            className="w-28 bg-bg border border-border hover:border-txt-muted focus:ring-2 focus:ring-brand/60 focus:ring-1 focus:ring-accent/30 rounded-lg px-3 py-2.5 text-txt-primary text-sm font-semibold focus:outline-none transition-colors"
          />
          {mcqCountNum > 0 && (
            <span className="text-sm text-txt-secondary">
              {mcqs.length} / {mcqCountNum} containers added
            </span>
          )}
        </div>

        <div className="mt-4 pt-4 border-t border-border/60">
          <p className="text-xs text-txt-muted mb-2">
            Or upload a JSON file to auto-create the containers and count. Include an
            "imageUrl" field per question if you have direct image links   otherwise
            you'll still need to attach each image manually after importing.
          </p>
          <JsonMcqImportButton mode="container" allowEmptyQuestion onImport={handleJsonImport} />
        </div>
      </StepCard>

      {/* ── Step 3: Subject % Breakdown ─────────────────────── */}
      <StepCard
        number="3"
        title="Subject Breakdown (optional)"
        description="A test usually covers more than one subject — add each one and roughly what share of the test it makes up. Shown to users on the Start Test popup."
      >
        <SubjectBreakdownEditor value={subjectBreakdown} onChange={handleSubjectBreakdownChange} />
      </StepCard>

      {/* ── Step 3: MCQ Containers ───────────────────────────── */}
      <StepCard
        id="mcq-containers-step"
        number="4"
        title="MCQ Containers"
        description={
          mcqCountNum > 0
            ? `Add up to ${mcqCountNum} MCQ containers. Each requires an image.`
            : "Set the MCQ count above before adding containers."
        }
      >
        {mcqCountNum > 0 ? (
          <MCQList
            mcqs={mcqs}
            totalMCQs={mcqCountNum}
            onChange={handleMcqsChange}
            onMcqEdit={handleSingleMcqEdit}
            onAddBatch={handleAddMcqBatch}
            showImageInput
            erroredIndex={erroredMcqIndex}
          />
        ) : (
          <div className="text-center py-8 text-txt-muted text-sm">
            Set the total MCQ count in Step 2 to unlock this section.
          </div>
        )}
      </StepCard>

      {/* ── Bottom save button (convenience) ────────────────── */}
      {mcqs.length > 0 && (
        <div className="flex flex-col items-end gap-2 pb-4">
          {finalSaveError && (
            <p className="text-xs text-danger text-right max-w-xs">{finalSaveError}</p>
          )}
          <button
            onClick={handleSaveSection}
            disabled={!canSave || isFinalSaving}
            className="inline-flex items-center gap-2 bg-accent hover:bg-accent-dark disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-semibold px-5 py-2.5 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-accent/50"
          >
            {isFinalSaving ? <Spinner /> : <SaveIcon />}
            {isFinalSaving ? "Saving…" : "Save Non-Verbal Section"}
          </button>
        </div>
      )}

      {/* ── Reduce count warning dialog ──────────────────────── */}
      {showReduceDialog && (
        <ReduceCountDialog
          removeCount={mcqs.length - (pendingCount ?? 0)}
          onConfirm={handleReduceConfirm}
          onCancel={handleReduceCancel}
        />
      )}

      {/* ── Leave-page confirmation (useBlocker) ─────────────── */}
      {blocker.state === "blocked" && (
        <LeavePageDialog
          onConfirm={() => blocker.proceed()}
          onCancel={() => blocker.reset()}
        />
      )}
    </div>
  );
}

// ── Export wrapped in per-page error boundary ─────────────────

export default function NonVerbalSectionPage() {
  return (
    <AdminErrorBoundary>
      <NonVerbalSectionPageInner />
    </AdminErrorBoundary>
  );
}