/**
 * src/pages/user/CategoryPage.jsx  (updated   consolidated onto SeoHead)
 *
 * Changes:
 *  - Removed serverHasAccess and serverUserExpired state   the server no longer
 *    returns per-category access flags. Access is determined purely client-side.
 *  - New rule: hasAccess = !!premiumUser (logged in and not expired).
 *    A logged-in, non-expired premium user sees every category unlocked.
 *  - userExpired is now derived from AuthContext's sessionExpired flag instead
 *    of a per-category server response.
 *  - fetch logic no longer reads hasAccess / userExpired from API response.
 *  - Swapped raw <Helmet> for <SeoHead> (see components/SeoHead.jsx) so this
 *    page gets Open Graph tags, Twitter card tags, and a canonical link like
 *    every other public page   previously it only got <title> +
 *    <meta name="description">, the one inconsistency in an otherwise
 *    site-wide SEO mechanism.
 *  - Added a lightweight CollectionPage + ItemList jsonLd schema (only on
 *    the default-category branch, where `tests` is already in state) listing
 *    the tests on the page   a clean fit since the data was already local,
 *    no extra fetch needed. Skipped on the custom-category branch: that
 *    branch hands off to CustomCategoryLayout before any test list is known
 *    here, so building a meaningful ItemList would mean either duplicating
 *    CustomCategoryLayout's own data-fetch or reaching into its internals   more
 *    complexity than this page's existing render logic can cleanly absorb.
 *  - Added a BreadcrumbList jsonLd schema (Home > {Category}), mirroring
 *    TestGroupPage.jsx's own BreadcrumbList one level down (Home > Category
 *    > Group). Unlike the ItemList above, this needs nothing from the
 *    `tests` fetch   only the slug/displayName that's already available
 *    the moment the page mounts   so it's emitted on BOTH branches
 *    (default category and custom category), not gated on loading state.
 */

import { useEffect, useState, useCallback } from "react";
import { getCached, setCached } from "../../utils/pageDataCache";
import { useParams, useOutletContext, Link } from "react-router-dom";
import SeoHead from "../../components/SeoHead";
import { useAuth } from "../../context/AuthContext";
import api from "../../api/axios";
import CategoryLockMessage from "../../public/components/CategoryLockMessage";
import CustomCategoryLayout, { CustomCategoryLayoutSkeleton } from "../../components/user/CustomCategoryLayout";
import AboutSection from "../../components/user/AboutSection";

const SITE_NAME = "PrepPK";
const BASE_URL  = import.meta.env.VITE_PUBLIC_URL || "https://www.prepkp.com";

// ── Section badge ─────────────────────────────────────────────
function SectionBadge({ label, status }) {
  const done = status === "ready";
  return (
    <span
      className={`inline-block text-xs px-3 py-1 rounded-full font-medium ${
        done
          ? "text-brand bg-brand-light dark:text-blue-300 dark:bg-blue-900/30"
          : "bg-bg text-txt-muted dark:bg-dark-surface2 dark:text-slate-500"
      }`}
    >
      {label}
    </span>
  );
}

// ── Test Card ─────────────────────────────────────────────────
function TestCard({
  test,
  isLoggedIn,
  hasAccess,
  userExpired,
  categoryName,
  onLockedClick,
}) {
  const isLocked = !hasAccess || userExpired;

  return (
    <div
      className={`bg-surface dark:bg-dark-surface rounded-xl border shadow-sm transition-all ${
        isLocked
          ? "border-border dark:border-dark-border opacity-90"
          : "border-border dark:border-dark-border hover:shadow-md hover:border-brand-light dark:hover:border-dark-border"
      }`}
    >
      <div className="p-5 space-y-3">
        {/* Header row: title + section badges */}
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-bold text-txt-primary dark:text-slate-100">{test.title}</h3>
            <div className="flex flex-wrap gap-1.5 mt-2">
              <SectionBadge label="Verbal"     status={test.sections.verbal} />
              <SectionBadge label="Non-Verbal" status={test.sections.nonVerbal} />
              <SectionBadge label="Academic"   status={test.sections.academic} />
            </div>
          </div>
        </div>

        {/* Action / lock message */}
        <CategoryLockMessage
          isLoggedIn={isLoggedIn}
          hasAccess={hasAccess}
          userExpired={userExpired}
          categoryName={categoryName}
          onBuyClick={() => onLockedClick(test)}
          renderUnlocked={
            <Link
              to={`/test/${test._id}`}
              className="inline-flex items-center text-xs font-bold bg-brand dark:bg-blue-500 hover:bg-brand-dark dark:hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition"
            >
              Start Test
            </Link>
          }
        />
      </div>
    </div>
  );
}

// ── Error card ────────────────────────────────────────────────
function ErrorCard({ message, onRetry }) {
  const isOffline = !navigator.onLine;
  return (
    <div className="bg-danger-light dark:bg-red-900/30 border border-danger/30 dark:border-red-700/30 rounded-xl p-6 text-center">
      <p className="text-sm font-semibold text-danger dark:text-red-300 mb-1">
        {isOffline ? "You appear to be offline." : "Could not load tests."}
      </p>
      <p className="text-xs text-danger dark:text-red-300 mb-4">
        {isOffline ? "Check your internet connection and try again." : message}
      </p>
      <button
        onClick={onRetry}
        className="text-xs font-bold bg-danger hover:bg-red-700 text-white px-4 py-2 rounded-lg transition"
      >
        Try Again
      </button>
    </div>
  );
}

// ── Skeleton ──────────────────────────────────────────────────
function SkeletonCard() {
  return (
    <div className="bg-surface dark:bg-dark-surface rounded-xl border border-border dark:border-dark-border shadow-sm p-5 animate-pulse">
      <div className="flex justify-between items-center">
        <div className="space-y-2 flex-1">
          <div className="h-4 bg-border dark:bg-dark-border rounded w-40" />
          <div className="flex gap-2 mt-2">
            <div className="h-5 bg-bg dark:bg-dark-bg rounded-full w-16" />
            <div className="h-5 bg-bg dark:bg-dark-bg rounded-full w-20" />
            <div className="h-5 bg-bg dark:bg-dark-bg rounded-full w-16" />
          </div>
        </div>
        <div className="h-8 w-20 bg-border dark:bg-dark-border rounded-lg" />
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────
export default function CategoryPage() {
  const { slug } = useParams();
  const { premiumUser, sessionExpired } = useAuth();
  const { openPremiumPopup, openLoginModal } = useOutletContext();

  const [tests,          setTests]          = useState([]);
  const [catName,        setCatName]        = useState("");
  const [catDescription, setCatDescription] = useState("");
  const [isDefault,      setIsDefault]      = useState(null); // null = loading
  const [blogContent,    setBlogContent]    = useState("");
  const [seoTitle,       setSeoTitle]       = useState("");
  const [seoDescription, setSeoDescription] = useState("");
  const [loading,        setLoading]        = useState(true);
  const [error,          setError]          = useState(null);

  // Whether we already know this category's type from a previous visit
  // this tab session (set below, after the first successful fetch). Used
  // only to pick the right-shaped loading skeleton before this fetch
  // resolves — never trusted for anything else.
  const cachedCategoryInfo = getCached(`category:${slug}`);
  // No cache yet (first visit this session) -> guess "custom", since that's
  // the newer layout and the one most categories use now. A wrong guess
  // just means the old default-category list flashes in afterward, same as
  // before this fix; a cached guess (repeat visit) is always correct.
  const probablyCustom = cachedCategoryInfo ? cachedCategoryInfo.isDefault === false : true;

  const isLoggedIn = !!premiumUser;

  // New access rule: any logged-in, non-expired premium user has full access.
  // No per-category check   if you're logged in and not expired, everything is unlocked.
  const hasAccess  = isLoggedIn && !sessionExpired;
  const userExpired = sessionExpired;

  const displayName =
    catName ||
    slug.split("-").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");

  // ── SEO values: use admin-set values or auto-generate ────────
  const pageTitle =
    seoTitle ||
    `${displayName} Mock Test 2025 | Online Practice | ${SITE_NAME}`;

  const pageDescription =
    seoDescription ||
    `Prepare for ${displayName} initial test with official-style MCQs. Free and premium mock tests covering Verbal, Non-Verbal, and Academic sections.`;

  const canonicalUrl = `${BASE_URL}/category/${slug}`;

  // ── BreadcrumbList jsonLd (Home > {Category}) ─────────────────
  // Doesn't depend on the tests fetch   only slug/displayName, both
  // available immediately   so it's always emitted, matching the
  // pattern TestGroupPage.jsx uses one level down.
  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type":    "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: BASE_URL },
      { "@type": "ListItem", position: 2, name: displayName, item: canonicalUrl },
    ],
  };

  // ── CollectionPage + ItemList jsonLd ──────────────────────────
  // Only meaningful once tests have actually loaded; an empty ItemList
  // isn't worth emitting, so this is omitted until then.
  const collectionSchema =
    !loading && tests.length > 0
      ? {
          "@context": "https://schema.org",
          "@type":    "CollectionPage",
          "@id":      `${canonicalUrl}#collectionpage`,
          url:        canonicalUrl,
          name:       pageTitle,
          description: pageDescription,
          mainEntity: {
            "@type": "ItemList",
            itemListElement: tests.map((test, i) => ({
              "@type":  "ListItem",
              position: i + 1,
              name:     test.title,
              url:      `${BASE_URL}/test/${test._id}`,
            })),
          },
        }
      : null;

  const jsonLd = [breadcrumbSchema, ...(collectionSchema ? [collectionSchema] : [])];

  const fetchTests = useCallback(() => {
    setLoading(true);
    setError(null);

    api
      .get(`/tests/category/${slug}`)
      .then(({ data }) => {
        setCatName(data.category?.name || "");
        setCatDescription(data.category?.description || "");
        setIsDefault(data.category?.isDefault !== false);
        setTests(data.tests || []);
        setBlogContent(data.category?.blogContent || "");
        setSeoTitle(data.category?.seoTitle || "");
        setSeoDescription(data.category?.seoDescription || "");
        // Note: we no longer read hasAccess / userExpired from the API response.
        // Access is determined entirely by AuthContext (isLoggedIn + sessionExpired).

        // Share the category name with anything else on this page that
        // needs it (currently: useChatContext), so it doesn't independently
        // re-fetch the same /tests/category/:slug endpoint.
        setCached(`category:${slug}`, {
          categoryName: data.category?.name || null,
          isDefault: data.category?.isDefault !== false,
        });
      })
      .catch((err) => {
        const msg =
          err.code === "ERR_NETWORK" || err.message === "Network Error"
            ? "Network error   check your connection."
            : "Failed to load tests. Please try again.";
        setError(msg);
      })
      .finally(() => setLoading(false));
  }, [slug]);

  useEffect(() => { fetchTests(); }, [fetchTests]);

  // Handler for locked-card click   only for non-logged-in visitors
  function handleLockedClick(test) {
    const intent = test
      ? {
          pathname:     `/category/${slug}`,
          action:       "start-test",
          testId:       test._id,
          categorySlug: slug,
        }
      : { pathname: `/category/${slug}` };

    openPremiumPopup({ mode: "visitor", intent });
  }

  // ── Header subtitle ────────────────────────────────────────
  function accessSubtitle() {
    if (!isLoggedIn)  return "Login or buy premium to unlock all tests.";
    if (userExpired)  return "Your subscription has expired. Contact admin to renew.";
    return "You have full access to all tests in this category.";
  }

  function accessBadge() {
    if (!isLoggedIn) return null;
    if (userExpired) {
      return (
        <div className="inline-flex items-center gap-1.5 mt-3 text-xs font-semibold px-3 py-1 rounded-full border bg-danger-light dark:bg-red-900/30 text-danger dark:text-red-300 border-danger/30 dark:border-red-700/30">
          ⚠ Subscription Expired
        </div>
      );
    }
    return (
      <div className="inline-flex items-center gap-1.5 mt-3 text-xs font-semibold px-3 py-1 rounded-full border bg-success-light dark:bg-green-900/30 text-green-700 dark:text-green-300 border-success/30 dark:border-green-700/30">
        ✓ Full Access
      </div>
    );
  }

  // ── Still loading, and it's probably a custom category: show the
  // matching hero/two-column skeleton instead of the old single-column
  // list one, so there's no visual jump once CustomCategoryLayout mounts.
  if (loading && probablyCustom) {
    return (
      <>
        <SeoHead
          title={pageTitle}
          description={pageDescription}
          url={canonicalUrl}
          ogType="website"
          jsonLd={[breadcrumbSchema]}
        />
        <CustomCategoryLayoutSkeleton categoryName={cachedCategoryInfo?.categoryName} />
      </>
    );
  }

  // ── Custom category: render CustomCategoryLayout ────────────
  if (!loading && isDefault === false) {
    const categoryObj = {
      name: displayName,
      slug,
      description: catDescription,
    };
    return (
      <>
        <SeoHead
          title={pageTitle}
          description={pageDescription}
          url={canonicalUrl}
          ogType="website"
          jsonLd={[breadcrumbSchema]}
        />
        <CustomCategoryLayout
          category={categoryObj}
          user={premiumUser}
          openLoginModal={openLoginModal}
          openPremiumPopup={openPremiumPopup}
        />
      </>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 md:px-8 py-10 dark:bg-dark-bg">
      {/* SEO meta tags */}
      <SeoHead
        title={pageTitle}
        description={pageDescription}
        url={canonicalUrl}
        ogType="website"
        jsonLd={jsonLd}
      />

      {/* Page header */}
      <div className="mb-8">
        <p className="text-xs text-brand dark:text-blue-400 font-semibold uppercase tracking-widest mb-1">
          Mock Tests
        </p>
        <h1 className="text-2xl font-bold text-txt-primary dark:text-slate-100">{displayName}</h1>
        <p className="text-txt-secondary dark:text-slate-300 font-semibold text-sm mt-1">{accessSubtitle()}</p>
        {accessBadge()}
      </div>

      {/* Test list */}
      {loading ? (
        <div className="space-y-3">
          <SkeletonCard /><SkeletonCard /><SkeletonCard />
        </div>
      ) : error ? (
        <ErrorCard message={error} onRetry={fetchTests} />
      ) : tests.length === 0 ? (
        <div className="bg-bg dark:bg-dark-surface border border-border dark:border-dark-border rounded-xl p-10 text-center text-txt-secondary dark:text-slate-300 text-sm">
          No published tests yet for this category.
        </div>
      ) : (
        <div className="space-y-3">
          {tests.map((test) => (
            <TestCard
              key={test._id}
              test={test}
              isLoggedIn={isLoggedIn}
              hasAccess={hasAccess}
              userExpired={userExpired}
              categoryName={displayName}
              onLockedClick={handleLockedClick}
            />
          ))}
        </div>
      )}

      {/* Bottom CTA for visitors only */}
      {!isLoggedIn && !loading && (
        <div className="mt-10 bg-brand-dark text-white rounded-2xl p-6 text-center">
          <p className="font-bold text-base mb-1">Ready to unlock all tests?</p>
          <p className="text-blue-200 text-sm mb-4">1 Week Rs. 300 <strong>or</strong> 1 Month Rs. 1,000</p>
          <button
            onClick={() => openPremiumPopup({ mode: "visitor" })}
            className="bg-accent hover:bg-accent-dark text-white font-bold text-sm px-6 py-2.5 rounded-full transition"
          >
            Buy Premium
          </button>
        </div>
      )}

      {/* About This Exam   SEO blog content section */}
      {!loading && !error && (
        <AboutSection blogContent={blogContent} />
      )}
    </div>
  );
}
